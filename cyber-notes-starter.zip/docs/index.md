# 🛡️ Networking Notes for Cybersecurity

Welcome! This site hosts my beginner-friendly notes for **Networking → Linux → Python** on my cybersecurity journey.  
Everything is written to be **clear, concise, and practical**.

---

## 📚 Contents

- **Networking**
  - [01 — Introduction](Networking/01_Introduction.html)

---

> Tip: Use the repo README to navigate files on GitHub directly, and this site (GitHub Pages) for a clean reading experience.
